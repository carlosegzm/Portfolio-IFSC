/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercico5;

import java.util.Scanner;

/**
 *
 * @author boli6
 */
public class Exercico5 {
    public static void main(String[] args) {
        
        Scanner input= new Scanner(System.in);
        System.out.println("Digite um valor para X: ");
        double x= input.nextDouble();
        double y= 3*x+2;
        System.out.println("O valor de y é igual a "+y);
        
    }
}
