
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author boli6
 */
public class Exercico1 {
    public static void main(String[] args) {
        
        int num;
        Scanner input= new Scanner(System.in);
        System.out.println("Digite um número");
        num= input.nextInt();
        System.out.println("O número digitado é "+num);
        
    }
}
